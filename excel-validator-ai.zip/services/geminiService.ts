
import { GoogleGenAI, Type } from "@google/genai";
import { ValidationRule } from "../types";

export const interpretRules = async (rulesText: string, headers: string[]): Promise<ValidationRule[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    I have an Excel file with the following headers: ${headers.join(', ')}.
    I have a set of validation rules written in plain text:
    ---
    ${rulesText}
    ---
    Please interpret these rules and convert them into a structured JSON array of validation rules.
    Match the column names in the rules to the provided headers exactly.
    
    CRITICAL REGEX RULES for JavaScript:
    - Patterns must NOT contain inline flags like (?i) or (?m). 
    - Instead, if a rule should be case-insensitive, set the "flags" property to "i".
    - Ensure patterns are valid for the JS 'new RegExp(pattern, flags)' constructor.

    Response Schema Requirements:
    - column: Must be the EXACT header name from the provided list.
    - ruleDescription: A concise explanation of what the rule is checking.
    - type: one of "regex", "range", "notEmpty".
    - params.pattern: The regex string (WITHOUT surrounding slashes or inline flags).
    - params.flags: Use "i" for case-insensitive, "g" for global, etc.
    - params.min/max: Numbers for "range" type.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        thinkingConfig: { thinkingBudget: 0 },
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              column: { type: Type.STRING },
              ruleDescription: { type: Type.STRING },
              type: { type: Type.STRING },
              params: {
                type: Type.OBJECT,
                properties: {
                  pattern: { type: Type.STRING },
                  flags: { type: Type.STRING },
                  min: { type: Type.NUMBER },
                  max: { type: Type.NUMBER }
                }
              }
            },
            required: ["column", "ruleDescription", "type"]
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    const result = JSON.parse(text.trim());
    return result as ValidationRule[];
  } catch (error) {
    console.error("Error interpreting rules with Gemini:", error);
    throw new Error("Failed to interpret validation rules. Please ensure your rules clearly mention the column headers.");
  }
};
