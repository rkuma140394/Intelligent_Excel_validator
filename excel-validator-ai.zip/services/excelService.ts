
import * as XLSX from 'xlsx';
import { RowData, ValidationRule, ValidationResult } from '../types';

export const parseExcel = (file: File): Promise<{ headers: string[], rows: RowData[] }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        if (jsonData.length === 0) {
          throw new Error("Excel file is empty");
        }

        const headers = (jsonData[0] as any[]).map(h => String(h).trim());
        const rows = XLSX.utils.sheet_to_json(worksheet) as RowData[];
        
        resolve({ headers, rows });
      } catch (error) {
        reject(error);
      }
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
};

export const validateRow = (row: RowData, rules: ValidationRule[]): ValidationResult => {
  const errors: string[] = [];
  
  for (const rule of rules) {
    // Exact match lookup, but fallback to case-insensitive trim match if AI hallucinated minor spacing
    const actualKey = Object.keys(row).find(k => k.trim() === rule.column.trim()) || rule.column;
    const value = row[actualKey];
    const stringValue = value === undefined || value === null ? '' : String(value).trim();
    
    switch (rule.type) {
      case 'notEmpty':
        if (stringValue === '') {
          errors.push(`${rule.column}: ${rule.ruleDescription}`);
        }
        break;
      case 'regex':
        if (rule.params?.pattern) {
          try {
            const regex = new RegExp(rule.params.pattern, rule.params.flags || '');
            if (!regex.test(stringValue)) {
              errors.push(`${rule.column}: ${rule.ruleDescription}`);
            }
          } catch (e) {
            console.error(`Regex Error for column ${rule.column}:`, e);
          }
        }
        break;
      case 'range':
        const numValue = typeof value === 'number' ? value : parseFloat(stringValue);
        if (isNaN(numValue)) {
          errors.push(`${rule.column}: Must be a valid number`);
        } else {
          if (rule.params?.min !== undefined && numValue < rule.params.min) {
            errors.push(`${rule.column}: ${rule.ruleDescription} (Value: ${numValue}, Min: ${rule.params.min})`);
          }
          if (rule.params?.max !== undefined && numValue > rule.params.max) {
            errors.push(`${rule.column}: ${rule.ruleDescription} (Value: ${numValue}, Max: ${rule.params.max})`);
          }
        }
        break;
    }
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

export const generateErrorExcel = (invalidRows: any[], originalFileName: string) => {
  const worksheet = XLSX.utils.json_to_sheet(invalidRows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Validation Errors");
  XLSX.writeFile(workbook, `Invalid_Rows_${originalFileName}`);
};
